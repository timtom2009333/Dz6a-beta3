
$$('.btn').forEach(btn => {
    btn.addEventListener('click', e => {
        const elem = e.currentTarget.querySelector('.btn-ripple');
        elem.classList.add('btn-ripple-animation');
        setTimeout(() => {elem.classList.remove('btn-ripple-animation');}, 1000);
    });
})

const game = new Game();
