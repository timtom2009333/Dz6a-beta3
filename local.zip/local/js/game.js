const $ = document.querySelector.bind(document);
const $$ = document.querySelectorAll.bind(document);

const px = num => parseInt(num) + 'px';

const collides = (o1, o2) => {
    return o1.x + o1.width >= o2.x && o1.x <= o2.x + o2.width
        && o1.y + o1.height >= o2.y && o1.y <= o2.y + o2.height;
};

const Modal = new class {

    closeAll() {
        $$('.modal').forEach(m => m.classList.remove('modal-show'));
    }

    open(name, single = true) {
        if (single) this.closeAll();

        $('.modal-'+name).classList.add('modal-show');
    }

}();

// Main class
class Game {

    constructor() {
        this.e = $('#game');
        this.width = this.e.clientWidth;
        this.height = this.e.clientHeight;

        this.paused = false;
        this.stopped = true;
        this.render();

        this.pressedKeys = [];
        this.eventListeners();


        this.SPEED = 3;
        this.MOVEMENT_SPEED = 5;
        this.WALL_WIDTH = 50;
        this.WALL_HEIGHT_MIN = 100;
        this.WALL_HEIGHT_MAX = 500;
        this.WALL_INTERVAL = 300;
        this.BATTERY_WIDTH = 87;
    }

    // Listeners for buttons and keyboard
    eventListeners() {
        $('#username').addEventListener('keyup', e => {
            if (e.currentTarget.value.trim() !== '') $('#play-btn').classList.remove('btn-block');
            else $('#play-btn').classList.add('btn-block');
        });

        const start = e => {
            if (!e.currentTarget.className.includes('btn-block')) this.start();
        }
        $('#play-btn').addEventListener('click', start);
        $('#restart-btn').addEventListener('click', start);
        $('#restart-btn-2').addEventListener('click', start);

        window.addEventListener('keydown', e => {
            if (e.keyCode === 27) return this.pause();
            if (!this.pressedKeys.find(k => k === e.keyCode)) this.pressedKeys.push(e.keyCode);
        });
        window.addEventListener('keyup', e => {
            this.pressedKeys = this.pressedKeys.filter(k => k !== e.keyCode);
        });
    }

    start() {
        $$('.wall, .battery, .element').forEach(e => e.remove());

        this.nickname = $('#username').value;
        Modal.closeAll();

        this.stopped = false;
        this.bgPosition = 0;
        this.time = 0;
        this.charge = 50;
        this.frameCount = 0;
        this.copter = new Copter(this);
        this.walls = [];
        this.batteries = [];
    }

    // Main render function
    render() {
        if (!this.paused && !this.stopped) {

            this.frameCount += 1;

            this.processKeys();
            this.copter.process();
            this.processWalls();
            this.processBatteries();

            this.bg();
            this.processIndicators();

        }
        requestAnimationFrame(() => {
            this.render();
        });
    }

    bg() {
        this.bgPosition -= this.SPEED;
        this.e.style.backgroundPosition = px(this.bgPosition);
    }

    processIndicators() {
        if (this.frameCount % 60 === 0) {
            this.time += 1;
            this.charge -= 1;
        }

        this.charge = Math.max(0, Math.min(100, this.charge));

        if (this.charge === 0) return this.end();
        if (this.charge <= 10) $('#gasoline-count').style.animation = '1s battery-low infinite';
        else $('#gasoline-count').style.animation = '';

        $('#username-block').innerText = this.nickname;
        $('#gasoline-count .gasoline-number').innerText = this.charge;
        $('#gasoline-count .gasoline-value').style.width = this.charge + '%';
        $('#timer-count').innerText = Math.floor(this.time / 60).toString().padStart(2, '0') + ':' + (this.time % 60).toString().padStart(2, '0');
    }

    processKeys() {
        this.pressedKeys.forEach(k => {
            switch (k) {
                case 87:
                    this.copter.y -= this.MOVEMENT_SPEED;
                    break;
                case 83:
                    this.copter.y += this.MOVEMENT_SPEED;
                    break;
            }
        });
    }

    processWalls() {
        if (this.walls.length === 0 || this.width - (this.walls[this.walls.length - 1].x + this.WALL_WIDTH) >= this.WALL_INTERVAL) this.walls.push(new Wall(this));

        this.walls.forEach(wall => wall.process());
    }

    processBatteries() {
        if (this.width - (this.walls[this.walls.length - 1].x + this.WALL_WIDTH) >= this.WALL_INTERVAL / 2 - this.BATTERY_WIDTH / 2 && (this.batteries.length === 0 || this.width - this.batteries[this.batteries.length - 1].x >= this.WALL_INTERVAL * 3 / 4))
            this.batteries.push(new Battery(this));

        this.batteries.forEach(battery => battery.process());
    }

    pause() {
        if (this.stopped) return;
        this.paused = !this.paused;

        if (this.paused) Modal.open('pause');
        else Modal.closeAll();
    }

    crashed() {
        this.stopped = true;

        this.copter.e.style.transition = '1s transform ease-in';
        this.copter.e.style.transform = 'translateY(700px) rotate(-180deg)';

        setTimeout(() => {
            Modal.open('lose');
        }, 1000);
    }

    end() {
        this.stopped = true;

        $('#result-nickname').innerText = this.nickname;
        $('#result-time').innerText = $('#timer-count').innerText;

        Modal.open('raking');
    }

}

// Class for handling player
class Copter {

    constructor(game) {
        this.game = game;
        this.createElement();

        this.width = 100;
        this.height = 101;

        this.x = 150;
        this.y = this.game.height / 2 - this.height / 2;
    }

    createElement() {
        this.e = document.createElement('img');
        this.e.id = 'player';
        this.e.className = 'element';
        this.e.src = 'img/quadcopter.png';
        this.e.alt = 'quadcopter';
        this.game.e.appendChild(this.e);
    }

    process() {
        this.y = Math.max(0, Math.min(this.game.height - this.height, this.y));

        this.e.style.top = px(this.y);
        this.e.style.left = px(this.x);
    }

}

// Class for handling walls
class Wall {

    constructor(game) {
        this.game = game;

        this.width = this.game.WALL_WIDTH;
        this.height = Math.round((this.game.WALL_HEIGHT_MIN + Math.random() * (this.game.WALL_HEIGHT_MAX - this.game.WALL_HEIGHT_MIN)));
        this.x = this.game.width;
        this.y = !!Math.round(Math.random()) ? 0 : this.game.height - this.height;

        this.createElement();
    }

    createElement() {
        this.e = document.createElement('div');
        this.e.className = 'wall';
        this.game.e.appendChild(this.e);
    }

    process() {
        this.x -= this.game.SPEED;

        this.e.style.top = px(this.y);
        this.e.style.left = px(this.x);
        this.e.style.height = px(this.height);
        this.e.style.width = px(this.width);

        if (collides(this.game.copter, this)) this.game.crashed();

        if (this.x <= 0) this.destroy();
    }

    destroy() {
        this.e.remove();
        this.game.walls.splice(this.game.walls.indexOf(this), 1);
    }

}

// Class for handling batteries
class Battery {

    constructor(game) {
        this.game = game;

        this.createElement();
        this.width = 87;
        this.height = 42;

        this.x = this.game.width;
        this.y = Math.round(Math.random() * (this.game.height - this.height));

        this.collected = false;
    }

    createElement() {
        this.e = document.createElement('img');
        this.e.className = 'battery';
        this.e.src = 'img/battery.png';
        this.e.alt = 'battery';
        this.game.e.appendChild(this.e);
    }

    process() {
        if (this.collected) return;

        this.x -= this.game.SPEED;

        this.e.style.top = px(this.y);
        this.e.style.left = px(this.x);

        if (collides(this, this.game.copter)) this.collect();

        if (this.x <= 0) this.destroy();
    }

    destroy() {
        this.e.remove();
        this.game.batteries.splice(this.game.batteries.indexOf(this), 1);
    }

    collect() {
        this.collected = true;
        this.game.charge += 5;

        this.e.style.transition = '.7s top, .7s left, .7s opacity, .7s transform';
        this.e.style.top = px(this.game.height / 2 - this.height / 2);
        this.e.style.left = px($('.panel-left').clientWidth / 2);
        this.e.style.opacity = '0';
        this.e.style.transform = 'scale(.5)';

        setTimeout(() => {
            this.destroy();
        }, 700);
    }

}
